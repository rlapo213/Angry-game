const express = require('express')
const logger = require('morgan')
const session = require('express-session')
const methodOverride = require('method-override')


const app = express()

const indexRouter = require('./Input/index.input')
const accountRouter = require('./Input/account.input')
const db = require('./db')

db.dbstart()

app.use(session({
    secret: "angry",
    saveUninitialized: true,
    resave: false
}))

app.use(logger('dev'))
app.use(methodOverride())
app.use(express.json())
app.use(express.urlencoded({extended: true}))



app.use('/', indexRouter)
app.use('/account', accountRouter)

app.set('views', './View')
app.set('view engine', 'ejs')

app.listen('3000', console.log("start"))