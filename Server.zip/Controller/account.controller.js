const model = require('../Model/user.model')

exports.login = (req, res) => {
    let data = {
        username: req.body.username,
        password: req.body.password
    }

    model.findOne({ username: data.username, password: data.password }).then(doc => {
        if (doc) {
            req.session.username = data.username
            res.json({ message: "login success" })
        } else {
            res.status(400).json({ message: "login error" })
        }
    })
}

exports.register = (req, res) => {
    let data = {
        username: req.body.username,
        password: req.body.password
    }

    model.findOne({ username: data.username }).then(doc => {
        if (doc) {
            res.status(400).json({ message: "register error" })
        } else {
            new model({ username: data.username, password: data.password, post: [] }).save().then(() => {
                res.json({ message: "register success"})
            })
        }
    })
}