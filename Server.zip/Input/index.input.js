const express = require('express')
const router = express.Router()

const indexController = require('../Controller/index.controller')

router.get('/', indexController.index)
router.get('/angry/:username', indexController.game)

module.exports = router