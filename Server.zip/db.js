const mongoose = require("mongoose")

exports.dbstart = config => {
    mongoose.connect('mongodb://localhost/server', {
        useNewUrlParser: true
    })
}