exports.index = (req, res) => {
    let data = {
        username: req.session.username
    }
    if (data.username) {
        res.render('Rlogin', { username: data.username })
    } else {
        res.render('Rlogin')
    }
}

exports.game = (req, res) => {
    let data = {
        username: req.params.username
    }
    res.render('game', { username: data.username })
}