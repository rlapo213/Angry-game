const express = require('express')
const router = express.Router()

const accountController = require('../Controller/account.controller')



router.post('/register', accountController.register)



module.exports = router